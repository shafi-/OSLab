#ifndef LookupResult_Class
#define LookupResult_Class
class LookupResult
{
public:
    bool isFound;
    unsigned char frameIndex;
};
#endif
