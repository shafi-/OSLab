#include "configuration.h"
#include "LookupResult.cpp"
#include "TranslationLookaheadBuffer.cpp"
#ifndef PageTable_Class
#define PageTable_Class
/*
class PageTableEntry
{
};
*/

class PageTable
{
public:
    /*
    * Add necessary class variables here
    */
    PageTable()
    {
        //write your code here
    }
    void setTranslationLookaheadBuffer(TranslationLookaheadBuffer *tlb){
        //write your code here
    }
    unsigned char getNextFreePageFrame()
    {
        //write your code here
    }
    LookupResult lookup(unsigned char pageNumber)
    {
        //write your code here
    }
    void insert(unsigned char pageNumber)
    {
        //write your code here
    }
    void invalidate(unsigned char pageNumber)
    {
        //write your code here
    }
    int getUsedPageCount()
    {
        //write your code here
    }
};
#endif
