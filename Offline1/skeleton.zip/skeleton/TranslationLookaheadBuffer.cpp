#include <map>
#include <iostream>
#include "configuration.h"
#include "LookupResult.cpp"

using namespace std;
#ifndef TranslationLookaheadBuffer_Class
#define TranslationLookaheadBuffer_Class
class TLBEntry
{
};
class TranslationLookaheadBuffer
{
public:
    /*
    * Add necessary class variables here
    */
    TranslationLookaheadBuffer(int size)
    {
        //write your code here
    }
    /*
    * Append a new TLB Entry into the end of the LRU Linked List
    * Will only be used in the LRU Implementation
    */
    void append(TLBEntry *t)
    {
        //write your code here
    }
    /*
    * Detach a TLB Entry from the LRU Linked List
    * Will only be used in the LRU Implementation
    */
    void detach(TLBEntry *t)
    {
        //write your code here
    }
    LookupResult lookup(unsigned char pageNumber){
        //write your code here
    }
    void insert(unsigned char pageNumber, unsigned char frameIndex)
    {
        //write your code here
    }
    void print()
    {
        //write your code here
    }
    void invalidate(unsigned char pageNumber)
    {
        //write your code here
    }
};
#endif
